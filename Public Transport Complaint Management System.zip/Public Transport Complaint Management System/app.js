const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

let loggedInUser = null;

// Routes
app.get('/', (req, res) => res.render('index'));

app.get('/register', (req, res) => res.render('register'));
app.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;
  db.query('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)', [name, email, password, role], (err) => {
    if (err) throw err;
    res.redirect('/login');
  });
});

app.get('/login', (req, res) => res.render('login'));
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.query('SELECT * FROM users WHERE email = ? AND password = ?', [email, password], (err, results) => {
    if (err) throw err;
    if (results.length > 0) {
      loggedInUser = results[0];
      res.redirect('/dashboard');
    } else {
      res.send("Invalid credentials");
    }
  });
});

app.get('/dashboard', (req, res) => {
  if (!loggedInUser) return res.redirect('/login');
  res.render('dashboard', { user: loggedInUser });
});

app.get('/file-complaint', (req, res) => {
  res.render('complaint_form');
});

app.post('/file-complaint', (req, res) => {
  const { title, description } = req.body;
  db.query('INSERT INTO complaints (user_id, title, description) VALUES (?, ?, ?)', [loggedInUser.id, title, description], (err) => {
    if (err) throw err;
    res.redirect('/my-complaints');
  });
});

app.get('/my-complaints', (req, res) => {
  db.query('SELECT * FROM complaints WHERE user_id = ?', [loggedInUser.id], (err, results) => {
    if (err) throw err;
    res.render('complaints_list', { complaints: results });
  });
});

app.get('/all-complaints', (req, res) => {
  if (!loggedInUser || loggedInUser.role !== 'authority') return res.redirect('/login');
  db.query(
    `SELECT c.*, u.name AS passenger_name 
     FROM complaints c 
     JOIN users u ON c.user_id = u.id`, 
    (err, results) => {
    if (err) throw err;
    res.render('all_complaints', { complaints: results });
  });
});

app.post('/update-status', (req, res) => {
  const { complaint_id, status } = req.body;
  db.query('UPDATE complaints SET status = ?, authority_id = ? WHERE id = ?', [status, loggedInUser.id, complaint_id], (err) => {
    if (err) throw err;
    db.query('INSERT INTO status_updates (complaint_id, update_text) VALUES (?, ?)', [complaint_id, `Marked as ${status}`], () => {
      res.redirect('/all-complaints');
    });
  });
});

app.get('/complaint/:id/timeline', (req, res) => {
  const id = req.params.id;
  db.query('SELECT * FROM status_updates WHERE complaint_id = ? ORDER BY updated_at ASC', [id], (err, results) => {
    if (err) throw err;
    res.render('timeline', { updates: results, id });
  });
});

app.get('/authority-dashboard', (req, res) => {
  if (!loggedInUser || loggedInUser.role !== 'authority') return res.redirect('/login');
  db.query(`
    SELECT 
      (SELECT COUNT(*) FROM complaints) AS total,
      (SELECT COUNT(*) FROM complaints WHERE status = 'Pending') AS pending,
      (SELECT COUNT(*) FROM complaints WHERE status = 'In Progress') AS progress,
      (SELECT COUNT(*) FROM complaints WHERE status = 'Resolved') AS resolved
  `, (err, result) => {
    if (err) throw err;
    res.render('authority_dashboard', { stats: result[0] });
  });
});


app.listen(3000, () => {
  console.log("🚀 Server running at http://localhost:3000");
});
