const mysql = require('mysql2');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Vanikrish2005_', // your MySQL password
  database: 'transport_complaints'
});

connection.connect(err => {
  if (err) throw err;
  console.log("Connected to MySQL");
});

module.exports = connection;
